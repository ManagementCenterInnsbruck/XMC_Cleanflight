#Notes

## Expected acc/mag/gyro behavior 

Observations of a flight-tested flip32 board in the configurator's 'raw sensor data' tab.

lift front of board (i.e. pitch back)
gyro y increases (green)
acc x increases (blue)
acc z decreases (red)
mag x decreases (blue)

lift left of boar (i.e. roll right)
gyro x increases (blue)
acc y increases (green)
mag y decreases (green)
mag z increases (red)
